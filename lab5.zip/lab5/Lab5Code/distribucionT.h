//=p-Distribucion T
//=b-30
#ifndef distribucionT_h
#define distribucionT_h
# define M_PIl          3.141592653589793238462643383279502884L /* pi */

#include <cmath>
#include <math.h>
#include <iostream>
using namespace std;
class distribucionT
{
public:
    double F(double X, int Dof);
    void PrimeraSeccion(int Dof);

private:
    double parte1;
    double FuncionGamma(double X);
};

//=i
//Funci�n llamada desde FunionT para evaluar el valor de x en Gamma.
double distribucionT::FuncionGamma(double X)
{
    //Caso base
	if(X == 1)
    {
        return 1.0;
    }
    //Caso base
	else if (X == 0.5)
    {
        return sqrt(M_PIl);
    }
    else
        //Seccion con recursividad
        return (X-1) * FuncionGamma(X - 1);
}

//=i
//Usado para calcular una unica vez la primera seccion de la funcion.
void distribucionT::PrimeraSeccion(int Dof)
{
    parte1 = FuncionGamma((Dof+1.0)/2) / (pow(Dof*M_PIl, 0.5) * FuncionGamma(Dof/2.0));
}
//=i
//Esta funci�n tiene como objetivo evaluar x con la distribuci�n T.
double distribucionT :: F(double X, int Dof)
{
    if(X != 0)
        return parte1 * (pow(1+ (pow(X,2)/Dof), -(Dof+1)/2.0));
    else
        return parte1 * (1);
}

#endif
