//=p-Simpson
//=b-92
#ifndef simpson_h
#define simpson_h

#include <iostream>
#include "distribucionT.h"

using namespace std;
class simpson
{
private:
    /* ----------------------------------------------------------*/
    //Vals precalclados
    //Es el n�mero de segmentos que se usara para el c�lculo.
    //Lo defino en el c�digo y debe de ser par.
    //El que se usara como inicial es 6. Lo damos en c�digo.
    int iNumSegmentos;
    //Es el error aceptable que tenemos. Se define en el c�digo.
    //El que se usara es .0000001.
    //Lo damos en c�digo.
    double E;

    /* ----------------------------------------------------------*/
    //Vals calculados por el codigo
    //Es el ancho del segmento.
    //Se obtiene dividiendo x con iNumSegementos.
    //Lo calculamos.
    double W;
    //Aqu� se almacenar� el valor de F (0). Lo calculamos.
    double F0;
    //Aqu� se almacenar� el valor de la sumatoria de los segmentos pares.
    //Lo calculamos.
    double FNon;
    //Aqu� se almacenar� el valor de la sumatoria de los segmentos nones.
    //Lo calculamos.
    double FPar;
    //Aqu� se almacenar� el valor de F(x). Lo calculamos.
    double FX;

    distribucionT calcu;

public:

    //Vals dados por el usuario
     //Valor que nos pasa la clase Main. Debe ser real mayor o igual a 0.
    double X;
    //Valor que nos pasa la clase Main. Debe ser entero mayor a 0.
    int Dof;
    //Esta variable almacenara la primera versi�n. Lo calculamos.
    double P1;
    //Esta variable almacena la segunda versi�n de P, la cual ser�
    //comparada con la primera versi�n. Lo calculamos.
    double P2;

    simpson();
    double ObtainW(double X, int iNumSegmentos);
    void SetNumeroSegmentos(int Num);
    void SetE(double Err);
    void SetX(double XMain);//=m
    void SetDof();
    double GetF0(int Dof);
    void GetSumSegmentos(double &FNon, double &FPar, int Dof, double W, int iNumSegmentos);
    double GetFX(double X, int Dof);
    void GetP();
};


//=i
simpson::simpson()
{
    iNumSegmentos = 0;
    W = 0.0;
    E = 0.0;
    X = 0.0;
    Dof = 0;
    P1 = 0.0;
    P2 = 0.0;
    F0 = 0.0;
    FNon = 0.0;
    FPar = 0.0;
    FX = 0.0;
}

//=i
//Esta funci�n de c�digo es para setear el valor inicial del n�mero de segmentos que se van
//a usar, desde el Main.
void simpson::SetNumeroSegmentos(int Num)
{
    iNumSegmentos = Num;
}

//=i
//Esta funci�n de c�digo es para setear el valor inicial del error aceptable, desde el Main.
void simpson::SetE(double Err)
{
    E = Err;
}

//=i
//Funci�n para setear el valor de X. Usado en Main.
void simpson::SetX(double XMain)//=m
{
    //=d-4
    X = XMain;
}

//=i
//Funci�n para setear el valor de Dof. Usado en Main.
void simpson::SetDof()
{
    do
    {
        cout << "Ingrese el valor de Dof" << endl;
        cin >> Dof;
    }while(Dof <= 0);
}

//=i
//La funcionalidad de este m�todo es para realizar el c�lculo de W.
double simpson::ObtainW(double X, int iNumSegmentos)
{
    return X/iNumSegmentos;
}

//=i
//Funci�n privada de la clase. Usada para calcular el valor de F (0)
double simpson::GetF0(int Dof)
{
    return calcu.F(0.0, Dof);
}

//=i
//Usado para el c�lculo de los segmentos, con una condicional se decide donde almacenarlos.
void simpson::GetSumSegmentos(double &FNon, double &FPar, int Dof, double W, int iNumSegmentos)
{
    double aux = 0.0;

    for(int i = 1; i < iNumSegmentos; i++)
    {
        aux = calcu.F(i*W,Dof);
        if(i%2 == 0)
        {
            FPar += 2*aux;
        }
        else
            FNon += 4*aux;
    }
}

//=i
//Usado para calcular F(X)
double simpson::GetFX(double X, int Dof)
{
    return calcu.F(X, Dof);
}

/*
Esta funci�n se llama desde el Main para obtener el valor de P el cual
almacenara en P1,  tras ello, se vuelve a llamar y compara, pero con
iNumSegmentos*2 y por ende se modifica la W. Debo ver que la diferencia entre
ambas sea menor a E, si lo es se queda el valor de P2, si no, vuelvo a llama a
la funci�n y P2 se escribe en P1. Regresamos el valor de P2.
*/
//=i
void simpson::GetP()
{
    W = ObtainW(X, iNumSegmentos);
    calcu.PrimeraSeccion(Dof);
    F0 = GetF0(Dof);
    GetSumSegmentos(FNon, FPar, Dof, W, iNumSegmentos);
    FX = GetFX(X, Dof);
    P1 = W/3 * (F0 + FNon + FPar + FX);

    FNon = 0.0;
    FPar = 0.0;

    while(true)
    {
        FNon = 0.0;
        FPar = 0.0;
        iNumSegmentos *= 2;
        W = ObtainW(X, iNumSegmentos);
        calcu.PrimeraSeccion(Dof);
        GetSumSegmentos(FNon, FPar, Dof, W, iNumSegmentos);
        P2 = W/3 * (F0 + FNon + FPar + FX);

        if((P2 - P1) < E)
        {
            return;
        }
        P1 = P2;
    }
}

#endif
