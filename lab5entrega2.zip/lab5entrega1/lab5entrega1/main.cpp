//=p-Clase Principal
//=b-19
//=d-10

#include <iostream>
#include "simpson.h"
#include <iomanip>

using namespace std;

//Variables globales para accesar facilmente
//Variable de simpson
simpson P;
//Variable de desplazamiento
double D = 1.0;


//=i
//Funcion para dar los valores iniciales a nuestra variable de simpson.
void pideVals()
{
    P.SetX(5); //=m
    P.SetDof();
    P.SetNumeroSegmentos(10);
    P.SetE(00.0000000000001);
}

//=i
//Funcion de control, que esta hecha para que el numero de segmentos regrese a su valor original.
void pideVals2()
{
    P.SetNumeroSegmentos(10);
    P.SetE(0.0000000000001);
}


//=i
//Funcion donde calculamos el valor de la X
void calculaX(double PDada)
{
    //Variable de control para el ciclo donde calculamos
    bool bControlCiclo = true;
    //En esta variable se almacena el valor del signo actual. 1 para suma y 2 para resta
    int signo = 0;
    //En esta variable almaceenamos el valor del signo de la operacion pasada, sige el mismo estandar.
    int SignoAnterior = 0;
    //Variable para almacenar el valor de X con las modificaciones.
    double temp = 10;

    //Ciclo donde calculamos
    while(bControlCiclo)
    {
        //Primero obtenemos el valor de P2
        P.GetP();

        //Realizamos las comparacicones.

        //Si es mas grande el valor de PDada debemos de sumar el desplazamiento a X.
        if(P.P2 - PDada < 0)
        {
            signo = 1;
        }
        //Si es mas chico el valor de PDada debemos de restar el desplazamiento a X.
        if(P.P2 - PDada > 0)
        {
            signo = 2;
        }

        //Cuando son iguales se termina el ciclo.
        if(P.P2 - PDada == 0.00000)
        {
            bControlCiclo = false;
        }

        //Si el signo anterior y actual son diferentes debo hacer el desplazamiento mas chico.
        if((SignoAnterior == 1 && signo == 2) || (SignoAnterior == 2 && signo == 1))
        {
            D = D/2;
        }


        if(signo == 1)
        {
            temp += D;
            P.SetX(temp);
            SignoAnterior = 1;
        }
        else if(signo == 2)
        {
            temp -= D;
            P.SetX(temp);
            SignoAnterior = 2;
        }

        pideVals2();
        signo = 0;
    }
}

//=i
//Funcion para imprimir los resultados
void imprime()
{
    cout << " P = " << setprecision(5) << fixed << P.P2 << endl;

    cout << " Dof = " << setprecision(5) << fixed << P.Dof << endl;

    cout << " X = " << setprecision(5) << fixed << P.X << endl;

}

int main()
{
    double PDada;

    //Ciclo para pedir el valor de la P del usuario
    do
    {
        cout << "Ingrese el valor de P" << endl;
        cin >> PDada;
    }while(PDada < 0  || PDada > 0.5);

    //Funcion para pedir los valores iniciales
    pideVals();

    //Llamamos a la funcion de calculo
    calculaX(PDada);

    //Llamamos a la funcion de imprimir.
    imprime();

    return 0;
}
